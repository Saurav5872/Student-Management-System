import { mockAuth } from "./mockAuth"
import { mockDb } from "./mockDb"

export const auth = mockAuth
export const db = mockDb

